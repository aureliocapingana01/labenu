

// const nomeFormatado = formatar( "nome ")

// function nomeDaFuncao(parametro1 , parametro2){
//     //açao 
//     return // saida
// }
















//-------- exercicio 1--------


    // function mostraNoConsoleFrase(  entrada )
    // {

    //    console.log(   `olá ` ,  entrada)


    // }

    // mostraNoConsoleFrase(  " camis ")
    // mostraNoConsoleFrase(  " luan ")
    // mostraNoConsoleFrase(  " fabricio ")



























//--------exemplos  declaração de funcao --------

// function mostraNoConsoleFrase(  entrada , entrada2)
// {

//    console.log(   entrada , entrada2  )
//     return // saida

// }





//-------- invocar a função  --------
//  mostraNoConsoleFrase( "nissan" ,  "fusca" )  


//----------- invocar mostrando no console --------
// console.log(
//       mostraNoConsoleFrase( "nissan" ,  "fusca" )  
//       )  

























//-------- exercicio 2 --------


    // function somarNumeros ( parametro , outroparametro ){

    //     const resultadoDaSoma = umNumero + outroNumero

    //     let  soma  = 2 + 3

    //     return resultadoDaSoma

    // }

    // const variavel1= 7 
    // const variavel2 = 100

    // console.log(      somarNumeros(  variavel1  ,variavel2  )        )




    

    // function somarNumeros ( parametro , outroparametro ){

    //     const resultadoDaSoma = umNumero + outroNumero

    //     let  soma  = 2 + 3

    //     return resultadoDaSoma

    // }













//-------- exercicio 3  --------




    //---------exercicio 1  em  funcao nomeada --------- // 

        // function mostraNoConsoleFrase(  entrada )
        // {

        //    console.log(   `olá ` ,  entrada)


        // }

        // mostraNoConsoleFrase(  " camis ")
        // mostraNoConsoleFrase(  " luan ")
        // mostraNoConsoleFrase(  " fabricio ")




    //--------exercicio 1   em    funcao anonima  --------- // 

        // const mostraNoConsoleFrase = function (  entrada )
        // {

        //    console.log(   `olá ` ,  entrada)


        // }

        // mostraNoConsoleFrase(  " camis ")
        // mostraNoConsoleFrase(  " luan ")
        // mostraNoConsoleFrase(  " fabricio ")




    //--------- exercicio 2 em  funcao nomeada    --------- // 


        // function somarNumeros ( parametro , outroparametro ){

        //     const resultadoDaSoma = umNumero + outroNumero
        //     return resultadoDaSoma

        // }


        // console.log(   somarNumeros(  2  ,5  )   )



    //--------- exercicio 2 em   funcao anonima  arrow   --------- // 

        // const somarNumeros =  ( parametro , outroparametro ) =>
        //   {
        //     const resultadoDaSoma = parametro + outroparametro
        //     return resultadoDaSoma
        // }


        // console.log(   somarNumeros(  2  , 5  )   )







    //---------  exercicio 1 com arrow function ---------

        // const  mostraNoConsoleFrase  =  ( entrada ) =>
        // {

        //    console.log(   `olá ` ,  entrada)


        // }

        // mostraNoConsoleFrase(  " camis ")
        // mostraNoConsoleFrase(  " luan ")
        // mostraNoConsoleFrase(  " fabricio ")


        // const  mostraNoConsoleFrase  =  ( entrada , entrada2 , entrada3 ) =>
        // {

        //    console.log(   `olá ` ,  entrada , entrada2 , entrada3)


        // }

        // mostraNoConsoleFrase(  " camis " , " luan " , " fabricio " )















